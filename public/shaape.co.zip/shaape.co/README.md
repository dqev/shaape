# Shaape Asset Pack (shaape.co)

A curated collection of over 1,600 abstract vector SVG shapes created for digital interfaces, branding, and graphic design.

## Included Folders
- `normal/`: Clean solid vector shapes (536 files)
- `gradient/`: Multi-tone gradient vector shapes (536 files)
- `grainy/`: Procedural noise-textured SVG vectors using native filters (536 files)

## License and Terms of Use
- Free to use for both personal and commercial projects.
- You may use these shapes in web applications, mobile apps, websites, client deliverables, print, branding, and video.
- You can freely edit, recolor, scale, and adapt the assets to fit your design system.
- Standalone redistribution or resale of the raw SVG files as a stock library or shape pack is prohibited.

## Attribution and Credits
Attribution is optional and not strictly required, but always appreciated.
If you would like to credit the project:
- Website: https://shaape.co
- Author: Dev Chauhan (https://x.com/devchauhann3)
- GitHub: https://github.com/dqev/shaape
